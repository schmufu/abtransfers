These icons can be used in personal as well as commercial projects.
If used in any project, credit to the author will be appreciated.

Diese Icons k�nnen sowohl in eigenen Projekten, wie in kommerziellen 
Projekten verwendet werden. Bei Verwendung w�re ein Backlink sehr nett.

http://www.m-worx.net

